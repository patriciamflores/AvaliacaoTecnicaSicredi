package com.patricia.votingmanagement.dto;

public record ProposalDTO (
		Long id,
		String description,
		String status) {
		
}
